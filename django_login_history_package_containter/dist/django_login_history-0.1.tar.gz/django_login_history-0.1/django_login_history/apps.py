from django.apps import AppConfig


class DjangoLoginHistoryConfig(AppConfig):
    name = 'django_login_history'
